from random import randint
import prompt


def check_even(num):
    return "yes" if num % 2 == 0 else "no"


def answer():
    number = randint(0, 100)
    print(f'Question: {number}')
    answer = prompt.string('Your answer: ')
    if answer == check_even(number):
        print("Correct!")
        return True
    else:
        print(f"'{answer}' is wrong answer ;(. Correct answer was '{check_even(number)}'.")
        return False
