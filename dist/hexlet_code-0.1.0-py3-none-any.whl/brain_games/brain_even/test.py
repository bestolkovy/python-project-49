from answer import answer

answer()
answer()