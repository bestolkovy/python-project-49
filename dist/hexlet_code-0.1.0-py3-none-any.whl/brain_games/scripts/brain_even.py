#!/usr/bin/env python3
from brain_games.brain_even.count import count


def main():
   count()


if __name__ == '__main__':
    main()
