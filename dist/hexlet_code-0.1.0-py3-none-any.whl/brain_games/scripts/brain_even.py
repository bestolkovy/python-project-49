#!/usr/bin/env python3
import brain_games.scripts.brain_games
from brain_games.brain_even.count import count


brain_games.scripts.brain_games.main()


def main():
   count()



if __name__ == '__main__':
    main()
